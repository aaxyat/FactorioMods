data:extend({
    {
        type = "double-setting",
        name = "botspeed-base-bot-speed",
        default_value = 0.144,
        minimum_value = 0.06,
        maximum_value = 1,
        setting_type = "startup"
    }
})