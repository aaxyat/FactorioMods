data:extend({
  {
    type = "bool-setting",
    name = "urq-print-completed-message",
    setting_type = "runtime-per-user",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "urq-show-disabled-techs",
    setting_type = "runtime-per-user",
    default_value = false,
  },
  {
    type = "bool-setting",
    name = "urq-show-control-hints",
    setting_type = "runtime-per-user",
    default_value = true,
  },
})
