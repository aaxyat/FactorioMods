data:extend({
    {
        name = 'sonaxaton-resource-map-markers-show-resource-name',
        order = '1',
        setting_type = 'runtime-per-user',
        type = 'bool-setting',
        default_value = true,
    },
    {
        name = 'sonaxaton-resource-map-markers-show-resource-amount',
        order = '2',
        setting_type = 'runtime-per-user',
        type = 'bool-setting',
        default_value = true,
    },
})
