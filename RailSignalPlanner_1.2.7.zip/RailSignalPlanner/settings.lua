data:extend({
  {
    type="bool-setting",
    name="rsp-toggle-menu-icon",
    setting_type = "runtime-per-user",
    default_value = true,
  }
})