require("api")

add_supported_rail("invisible_rail", false, true) -- cargo-ships
add_supported_rail("bridge_crossing", false, true) -- cargo-ships
add_supported_rail("naked-straight-rail", nil, true) -- naked rails
add_supported_rail("naked-sleepy-straight-rail", nil, true) -- naked rails
add_supported_rail("naked-curved-rail", nil, true) -- naked rails
add_supported_rail("naked-sleepy-curved-rail", nil, true) -- naked rails
