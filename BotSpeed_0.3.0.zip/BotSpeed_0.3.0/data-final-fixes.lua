-- data-final-fixes

new_base_speed = settings.startup["botspeed-base-bot-speed"].value

data.raw["construction-robot"]["construction-robot"].speed = new_base_speed
data.raw["logistic-robot"]["logistic-robot"].speed = new_base_speed

if data.raw["construction-robot"]["construction-robot-nuclear"] then
    data.raw["construction-robot"]["construction-robot-nuclear"].speed = 1.5 * new_base_speed
end

if data.raw["logistic-robot"]["logistic-robot-nuclear"] then
    data.raw["construction-robot"]["construction-robot-nuclear"].speed = new_base_speed
end

if data.raw["construction-robot"]["construction-robot-mk2"] then
    data.raw["construction-robot"]["construction-robot-mk2"].speed = 2 * new_base_speed
end

if data.raw["construction-robot"]["construction-robot-mk3"] then
    data.raw["construction-robot"]["construction-robot-mk3"].speed = 3 * new_base_speed
end

if data.raw["logistic-robot"]["logistic-robot-mk2"] then
    data.raw["logistic-robot"]["logistic-robot-mk2"].speed = 2 * new_base_speed
end

if data.raw["logistic-robot"]["logistic-robot-mk3"] then
    data.raw["logistic-robot"]["logistic-robot-mk3"].speed = 3 * new_base_speed
end
