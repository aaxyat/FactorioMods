global.translations = {}
