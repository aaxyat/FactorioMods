data:extend{{
    type = "custom-input",
    name = "bv-highlight-belt",
    key_sequence = "H",
    alternative_key_sequence = "SHIFT + H",
    action = "lua"
},
-- {
--     type = "custom-input",
--     name = "bv-highlight-ghost",
--     key_sequence = "SHIFT + H",
--     action = "lua"
-- }
}