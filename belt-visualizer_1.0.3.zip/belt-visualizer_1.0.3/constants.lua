local offset = 0.234375 -- 15/64
local width = 3
local color = {1, 1, 0}
local radius = width * 1.25 / 32
local size = width * 1.125 / 32

local function generate(distance, _offset_1, _offset_2)
    local offset_1 = _offset_1 or offset
    local offset_2 = _offset_2 or offset_1
    local left = {
        [0] = {-offset_1, -distance},
        [2] = {distance, -offset_1},
        [4] = {offset_1, distance},
        [6] = {-distance, offset_1},
    }
    local right = {
        [0] = {offset_2, -distance},
        [2] = {distance, offset_2},
        [4] = {-offset_2, distance},
        [6] = {-distance, -offset_2},
    }
    return {left, right}
end

local function rectangle(offsets, size)
    local left_top = {{}, {}}
    local right_bottom = {{}, {}}
    for lane, directions in pairs(offsets) do
        for direction, offset in pairs(directions) do
            left_top[lane][direction] = {offset[1] - size, offset[2] - size}
            right_bottom[lane][direction] = {offset[1] + size, offset[2] + size}
        end
    end
    return {left_top = left_top, right_bottom = right_bottom}
end

local sideload = 1 - offset

local straight = {
    input = generate(-0.5),
    output = generate(0.5),
    sideload = generate(sideload),
}

local curved = {
    [0] = {-0.5, -0.5},
    [2] = {0.5, -0.5},
    [4] = {0.5, 0.5},
    [6] = {-0.5, 0.5},
}

local pixel_width = width / 32
local inner_min = 0.5 - offset - pixel_width / 2
local inner_max = 0.5 - offset + pixel_width / 2
local outer_min = 0.5 + offset - pixel_width / 2
local outer_max = 0.5 + offset + pixel_width / 2
local arc_radius = {
    {min = inner_min, max = inner_max},
    {min = outer_min, max = outer_max},
}

local dash_length = 3/16
local dash_offset = 0.5 - dash_length / 2
local gap_length = 0.5 - dash_length
local endpoint = 0.5 - (dash_length / 2 + gap_length)
local underground = {
    input = generate(endpoint),
    output = generate(-endpoint),
}
local dash = {
    input = generate(dash_offset),
    output = generate(-dash_offset),
}

local outer_offset = 0.5 + offset
local inner_offset = 0.5 - offset
local outer_line = outer_offset + width / 64
local inner_line = inner_offset + width / 64
local splitter = {
    left = {
        input = generate(-0.5, outer_offset, -inner_offset),
        output = generate(0.5, outer_offset, -inner_offset),
        middle = generate(0, outer_offset, -inner_offset),
        sideload = generate(sideload, outer_offset, -inner_offset),
        line = generate(0, outer_line, -inner_line),
    },
    right = {
        input = generate(-0.5, -inner_offset, outer_offset),
        output = generate(0.5, -inner_offset, outer_offset),
        middle = generate(0, -inner_offset, outer_offset),
        sideload = generate(sideload, -inner_offset, outer_offset),
        line = generate(0, -inner_line, outer_line),
    }
}

local loader = {
    input = generate(-1),
    output = generate(1),
    sideload = generate(sideload + 0.5)
}

local loader_rectangle = {
    input = rectangle(loader.output, size),
    output = rectangle(loader.input, size),
}

local loader_1x1 = {
    input = generate(-0.5),
    output = generate(0.5),
    sideload = generate(sideload),
}
local loader_1x1_rectangle = {
    input = rectangle(loader_1x1.output, size),
    output = rectangle(loader_1x1.input, size),
}

local linked_belt = {
    input = generate(-0.5),
    output = generate(0.5),
    middle = generate(0),
    sideload = generate(sideload)
}

return {
    offset = offset,
    width = width,
    color = color,
    radius = radius,
    straight = straight,
    curved = curved,
    arc_radius = arc_radius,
    underground = underground,
    dash = dash,
    dash_length = dash_length,
    gap_length = gap_length,
    splitter = splitter,
    loader = loader,
    loader_rectangle = loader_rectangle,
    loader_1x1 = loader_1x1,
    loader_1x1_rectangle = loader_1x1_rectangle,
    linked_belt = linked_belt,
}