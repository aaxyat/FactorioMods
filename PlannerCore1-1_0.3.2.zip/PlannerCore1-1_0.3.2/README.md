# PlannerCore

Core mod for the planner series of mods ([Outpost Planner](https://github.com/ChucklesTheBeard/OutpostPlanner)).

This mod contains most of the code, allowing the mods to call each other without all of them being installed.

[Link to Factorio mod website](https://mods.factorio.com/mods/ChucklesTheBeard/PlannerCore1-1)

Please submit bug reports to the issues page of the mod you're using when the crash occurs instead of here.

