data:extend{{
    type = "custom-input",
    name = "bv-highlight-belt",
    key_sequence = "SHIFT + H",
    action = "lua"
}}