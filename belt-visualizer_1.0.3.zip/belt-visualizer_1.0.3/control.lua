local const = require("constants")
local straight = const.straight
local curved = const.curved
local arc_radius = const.arc_radius
local underground = const.underground
local dash = const.dash
local splitter = const.splitter
local loader = const.loader
local loader_rectangle = const.loader_rectangle
local loader_1x1 = const.loader_1x1
local loader_1x1_rectangle = const.loader_1x1_rectangle
local linked_belt = const.linked_belt
local sides = {"left", "right"}

script.on_init(function()
    global.players = {}
    global.in_progress = {}
end)
script.on_configuration_changed(function()
    rendering.clear("belt-visualizer")
    global.players = {}
    global.in_progress = {}
end)

local connectables = {
    ["transport-belt"] = true,
    ["underground-belt"] = true,
    ["splitter"] = true,
    ["loader"] = true,
    ["loader-1x1"] = true,
    ["linked-belt"] = true,
}

local lane_cycle = {
    {true, true},
    {[1] = true},
    {[2] = true},
}

local function empty_check(type)
    return type == "splitter" and {left = {{{}, {}}, {{}, {}}}, right = {{{}, {}}, {{}, {}}}} or {{}, {}}
end

local function clear(index)
    if not global.players[index] then return end
    for id in pairs(global.players[index].ids) do
        if rendering.is_valid(id) then
            rendering.destroy(id)
        end
    end
end

local function remove_player(event)
    local index = event.player_index
    clear(index)
    global.players[index] = nil
    global.in_progress[index] = nil
end

script.on_event(defines.events.on_player_left_game, remove_player)
script.on_event(defines.events.on_player_removed, remove_player)

script.on_event("bv-highlight-belt", function(event)
    local index = event.player_index
    local player = game.get_player(index) ---@cast player LuaPlayer
    local selected = player.selected
    if not (selected and connectables[selected.type]) then remove_player(event) return end
    clear(index)
    global.players[index] = global.players[index] or {}
    local data = global.players[index]
    data.cycle = data.origin == selected.unit_number and data.cycle % 3 + 1 or 1
    data.index = index
    data.origin = selected.unit_number
    data.next_entities = {[selected.unit_number] = {data = selected, lanes = lane_cycle[data.cycle], paths = {true, true}}}
    data.checked = {}
    data.checked[selected.unit_number] = empty_check(selected.type)
    data.ids = {}
    global.in_progress[index] = true
end)

local function draw_line(player, entity, from_offset, to_offset)
    player.ids[rendering.draw_line{
        color = const.color,
        width = const.width,
        from = entity,
        to = entity,
        from_offset = from_offset,
        to_offset = to_offset,
        surface = entity.surface,
        players = {player.index},
    }] = true
end

local function draw_dash(player, entity, from_offset, to_offset)
    player.ids[rendering.draw_line{
        color = const.color,
        width = const.width,
        from = entity,
        to = entity.neighbours,
        from_offset = from_offset,
        to_offset = to_offset,
        dash_length = const.dash_length,
        gap_length = const.gap_length,
        surface = entity.surface,
        players = {player.index},
    }] = true
end

local function draw_arc(player, entity, lane, clockwise)
    local offset = clockwise and 2 or 0
    lane = clockwise and lane % 2 + 1 or lane
    local start_angle = (entity.direction + offset) * 45 % 360
    player.ids[rendering.draw_arc{
        color = const.color,
        min_radius = arc_radius[lane].min,
        max_radius = arc_radius[lane].max,
        start_angle = math.rad(start_angle) --[[@as float]],
        angle = math.rad(90) --[[@as float]],
        target = entity,
        target_offset = curved[(entity.direction + offset) % 8],
        surface = entity.surface,
        players = {player.index},
    }] = true
end

local function draw_circle(player, entity, offset)
    player.ids[rendering.draw_circle{
        color = const.color,
        radius = const.radius,
        filled = true,
        target = entity,
        target_offset = offset,
        surface = entity.surface,
        players = {player.index},
    }] = true
end

local function draw_rectangle(player, entity, lane, offsets)
    player.ids[rendering.draw_rectangle{
        color = const.color,
        filled = true,
        left_top = entity,
        left_top_offset = offsets.left_top[lane][entity.direction],
        right_bottom = entity,
        right_bottom_offset = offsets.right_bottom[lane][entity.direction],
        surface = entity.surface,
        players = {player.index},
    }] = true
end

local function is_clockwise(entity, output)
    local clockwise = (output.direction - entity.direction) % 8 == 2
    return clockwise
end

local function get_splitter_sides(entity, belt)
    local axis = entity.direction % 4 == 0 and "x" or "y"
    local invert = entity.direction >= 4
    if entity.position[axis] == belt.position[axis] then return {"left", "right"} end
    return entity.position[axis] > belt.position[axis] ~= invert and {"left"} or {"right"}
end

local function get_next_lanes(entity, lanes, output)
    if not output or entity.direction == output.direction then return lanes, {"output", "output"} end
    local clockwise = is_clockwise(entity, output)
    local next_lanes = {}
    local offsets = {}
    if output.type == "underground-belt" then
        for lane in pairs(lanes) do
            local type = output.belt_to_ground_type == "input"
            if (clockwise == type) == (lane == 1) then
                next_lanes[clockwise and 2 or 1] = true
                offsets[lane] = "sideload"
            else
                offsets[lane] = "output"
            end
        end
    else
        if #output.belt_neighbours.inputs ~= 1 then
            for lane in pairs(lanes) do
                next_lanes[clockwise and 2 or 1] = true
                offsets[lane] = "sideload"
            end
        else
            return lanes, {"output", "output"}
        end
    end
    return next_lanes, offsets
end

local function get_prev_lanes(entity, lanes, input)
    if entity.direction == input.direction then return lanes end
    local clockwise = is_clockwise(input, entity)
    for lane in pairs(lanes) do
        if clockwise == (lane == 2) then
            if entity.type == "underground-belt" then
                local type = entity.belt_to_ground_type == "input"
                return clockwise == type and {[1] = true} or {[2] = true}
            else
                return {true, true}
            end
        end
    end
end

local function add_to_queue(player, old_entity, lanes, entity, path)
    if not entity then return end
    if entity.type == "entity-ghost" then return end
    for lane in pairs(lanes) do
        local checked
        if entity.type == "splitter" then
            player.checked[entity.unit_number] = player.checked[entity.unit_number] or empty_check(entity.type)
            for _, side in pairs(get_splitter_sides(entity, old_entity)) do
                checked = player.checked[entity.unit_number][side][path % 2 + 1][lane][path]
            end
        else
            player.checked[entity.unit_number] = player.checked[entity.unit_number] or empty_check(entity.type)
            checked = player.checked[entity.unit_number][lane][path]
        end
        if not checked then
            player.next_entities[entity.unit_number] = player.next_entities[entity.unit_number] or {data = entity, lanes = {}, paths = {}}
            player.next_entities[entity.unit_number].lanes[lane] = true
            player.next_entities[entity.unit_number].paths[path] = true
        end
    end
end

local highlight_entity = {
    ["transport-belt"] = function(player, entity, lanes, paths)
        local check = player.checked[entity.unit_number]
        local direction = entity.direction
        local inputs = entity.belt_neighbours.inputs
        local type = (#inputs == 1) and (direction ~= inputs[1].direction) and "curved" or "straight"
        local output = entity.belt_neighbours.outputs[1]
        local next_lanes, offsets = get_next_lanes(entity, lanes, output)
        for lane in pairs(lanes) do
            if not next(check[lane]) then
                local offset = offsets[lane]
                if type == "straight" then
                    draw_line(player, entity, straight.input[lane][direction], straight[offset][lane][direction])
                else
                    draw_arc(player, entity, lane, is_clockwise(inputs[1], entity))
                    if offset == "sideload" then
                        draw_line(player, entity, straight.output[lane][direction], straight[offset][lane][direction])
                    end
                end
            end
            for path in pairs(paths) do
                check[lane][path] = true
            end
        end
        if paths[1] then
            add_to_queue(player, entity, next_lanes, output, 1)
        end
        if paths[2] then
            for _, input in pairs(entity.belt_neighbours.inputs) do
                local prev_lanes = type == "curved" and lanes or get_prev_lanes(entity, lanes, input)
                if prev_lanes then add_to_queue(player, entity, prev_lanes, input, 2) end
            end
        end
    end,
    ["underground-belt"] = function(player, entity, lanes, paths)
        local check = player.checked[entity.unit_number]
        local direction = entity.direction
        local type_input = entity.belt_to_ground_type == "input"
        local output = entity.belt_neighbours.outputs[1]
        local next_lanes, offsets = get_next_lanes(entity, lanes, output)
        for lane in pairs(lanes) do
            if not next(check[lane]) then
                if type_input then
                    draw_line(player, entity, straight.input[lane][direction], underground.input[lane][direction])
                else
                    local offset = offsets[lane]
                    draw_line(player, entity, underground.output[lane][direction], straight[offset][lane][direction])
                end
            end
            for path in pairs(paths) do
                check[lane][path] = true
            end 
        end
        if paths[1] then
            add_to_queue(player, entity, next_lanes, output, 1)
            if type_input and entity.neighbours then
                local neighbour_check = player.checked[entity.neighbours.unit_number]
                for lane in pairs(lanes) do
                    if not (neighbour_check and next(neighbour_check[lane])) then
                        draw_dash(player, entity, dash.input[lane][direction], dash.output[lane][direction])
                    end
                end
                add_to_queue(player, entity, lanes, entity.neighbours, 1)
            end
        end
        if paths[2] then
            for _, input in pairs(entity.belt_neighbours.inputs) do
                local prev_lanes = get_prev_lanes(entity, lanes, input)
                if prev_lanes then add_to_queue(player, entity, prev_lanes, input, 2) end
            end
            if not type_input and entity.neighbours then
                local neighbour_check = player.checked[entity.neighbours.unit_number]
                for lane in pairs(lanes) do
                    if not (neighbour_check and next(neighbour_check[lane])) then
                        draw_dash(player, entity.neighbours, dash.input[lane][direction], dash.output[lane][direction])
                    end
                end
                add_to_queue(player, entity, lanes, entity.neighbours, 2)
            end
        end
    end,
    ["splitter"] = function(player, entity, lanes, paths)
        local direction = entity.direction
        local check = player.checked[entity.unit_number]
        local neighbours = entity.belt_neighbours
        for path in pairs(paths) do
            local forward = path == 1
            local belts = {}
            for _, belt in pairs(neighbours[forward and "outputs" or "inputs"]) do
                for _, side in pairs(get_splitter_sides(entity, belt)) do
                    belts[side] = belt
                end
            end
            for _, side in pairs(sides) do
                local next_lanes, offsets = get_next_lanes(entity, lanes, belts[side])
                for lane in pairs(lanes) do
                    if not next(check[side][path][lane]) then
                        local offset = forward and offsets[lane] or "input"
                        draw_line(player, entity, splitter[side].middle[lane][direction], splitter[side][offset][lane][direction])
                        draw_line(player, entity, splitter.left.line[lane][direction], splitter.right.line[lane][direction])
                    end
                    check[side][path][lane][path] = true
                end
                add_to_queue(player, entity, next_lanes, belts[side], path)
            end
            for _, belt in pairs(neighbours[forward and "inputs" or "outputs"]) do
                local belt_check = player.checked[belt.unit_number]
                if belt_check then
                    for _, side in pairs(get_splitter_sides(entity, belt)) do
                        local _, offsets = get_next_lanes(entity, lanes, belt)
                        for lane in pairs(lanes) do
                            if not next(check[side][path%2+1][lane]) then
                                local offset = forward and "input" or offsets[lane]
                                draw_line(player, entity, splitter[side].middle[lane][direction], splitter[side][offset][lane][direction])
                            end
                            check[side][path%2+1][lane][path] = true
                        end
                    end
                end
            end
        end
    end,
    ["loader"] = function(player, entity, lanes, paths)
        local check = player.checked[entity.unit_number]
        local direction = entity.direction
        local output = entity.belt_neighbours.outputs[1]
        local next_lanes, offsets = get_next_lanes(entity, lanes, output)
        for lane in pairs(lanes) do
            if not next(check[lane]) then
                local offset = offsets[lane]
                draw_line(player, entity, loader.input[lane][direction], loader[offset][lane][direction])
                draw_rectangle(player, entity, lane, loader_rectangle[entity.loader_type])
            end
            for path in pairs(paths) do
                check[lane][path] = true
            end
        end
        if paths[1] then
            add_to_queue(player, entity, next_lanes, output, 1)
        end
        if paths[2] then
            add_to_queue(player, entity, next_lanes, entity.belt_neighbours.inputs[1], 2)
        end
    end,
    ["loader-1x1"] = function(player, entity, lanes, paths)
        local check = player.checked[entity.unit_number]
        local direction = entity.direction
        local output = entity.belt_neighbours.outputs[1]
        local next_lanes, offsets = get_next_lanes(entity, lanes, output)
        for lane in pairs(lanes) do
            if not next(check[lane]) then
                local offset = offsets[lane]
                draw_line(player, entity, loader_1x1.input[lane][direction], loader_1x1[offset][lane][direction])
                draw_rectangle(player, entity, lane, loader_1x1_rectangle[entity.loader_type])
            end
            for path in pairs(paths) do
                check[lane][path] = true
            end
        end
        if paths[1] then
            add_to_queue(player, entity, next_lanes, output, 1)
        end
        if paths[2] then
            add_to_queue(player, entity, next_lanes, entity.belt_neighbours.inputs[1], 2)
        end
    end,
    ["linked-belt"] = function(player, entity, lanes, paths)
        local check = player.checked[entity.unit_number]
        local direction = entity.direction
        local type = entity.linked_belt_type
        local output = entity.belt_neighbours.outputs[1]
        local next_lanes, offsets = get_next_lanes(entity, lanes, output)
        for lane in pairs(lanes) do
            if not next(check[lane]) then
                if type == "input" then
                    draw_line(player, entity, linked_belt.input[lane][direction], linked_belt.middle[lane][direction])
                else
                    local offset = offsets[lane]
                    draw_line(player, entity, linked_belt.middle[lane][direction], linked_belt[offset][lane][direction])
                end
                draw_circle(player, entity, linked_belt.middle[lane][direction])
            end
            for path in pairs(paths) do
                check[lane][path] = true
            end
        end
        if paths[1] then
            add_to_queue(player, entity, next_lanes, output, 1)
            if type == "input" then
                add_to_queue(player, entity, lanes, entity.linked_belt_neighbour, 1)
            end
        end
        if paths[2] then
            add_to_queue(player, entity, next_lanes, entity.belt_neighbours.inputs[1], 2)
            if type == "output" then
                add_to_queue(player, entity, lanes, entity.linked_belt_neighbour, 2)
            end
        end
    end,
}

script.on_event(defines.events.on_tick, function()
    local length = table_size(global.in_progress)
    for index in pairs(global.in_progress) do
        local player = global.players[index]
        local i = 0
        while i < settings.global["highlight-maximum"].value / length do
            local id, entity = next(player.next_entities)
            if not id then break end
            if entity.data.valid then
                highlight_entity[entity.data.type](player, entity.data, entity.lanes, entity.paths)
            end
            player.next_entities[id] = nil
            i = i + 1
        end
        if not next(player.next_entities) then global.in_progress[player.index] = nil end
    end
end)